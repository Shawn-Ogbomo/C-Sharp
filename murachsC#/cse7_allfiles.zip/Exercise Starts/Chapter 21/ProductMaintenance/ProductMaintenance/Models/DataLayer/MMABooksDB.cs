﻿namespace ProductMaintenance.Models.DataLayer
{
    public static class MMABooksDB
    {
        public static readonly string ConnectionString = "";
    }
}