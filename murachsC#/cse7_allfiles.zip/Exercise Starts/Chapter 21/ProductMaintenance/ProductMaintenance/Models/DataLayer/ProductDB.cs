﻿namespace ProductMaintenance.Models.DataLayer
{
    public static class ProductDB
    {
        public static Product GetProduct(string productCode)
        {
            return null;
        }

        public static void AddProduct(Product product)
        {
            
        }

        public static bool UpdateProduct(Product oldProduct, Product newProduct)
        {
            return false;        
        }

        public static bool DeleteProduct(Product product)
        {
            return false;        
        }
    }
}