﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomerInvoices
{
    public class Customer
    {
        public int CustomerID { get; set; }
        public string Name { get; set; }
    }
}
